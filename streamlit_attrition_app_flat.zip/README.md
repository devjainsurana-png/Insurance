# HR Attrition Intelligence (Streamlit Cloud)

Main file: `app.py`

## Deploy
1) Push `app.py`, `requirements.txt`, and `README.md` to your GitHub repo root.
2) On Streamlit Cloud, point to `app.py`.
3) Upload `EA.csv` inside the app (or place it in repo root for auto-load).

## Features
- 5 Insight charts with JobRole multiselect + Satisfaction slider (global filters).
- Models tab with DT, RF, GBRT; cv=5 stratified, confusion matrices (train/test), metrics table, ROC overlay, CV summary, feature importances.
- Predict tab to upload new data and download predictions.
- Nulls handled: numeric→mean, categorical→mode; unknown categories handled by OrdinalEncoder.
- No version pins in `requirements.txt`.
